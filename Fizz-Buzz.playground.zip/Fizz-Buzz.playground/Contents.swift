//: Playground - noun: a place where people can play

import UIKit

let number = 1...105

for num in number {
    
    if num % 3 == 0 && num % 5 == 0 && num % 7 == 0 {
        print("\(num) fizz-buzz-bang")
    }
    else if num % 3 == 0 && num % 5 == 0{
        print("\(num) fizz-buzz")
    }
    else if num % 3 == 0 {
        print("\(num) fizz")
    }
    else if num % 5 == 0 {
        print("\(num) buzz")
    }
    else {
        print(num)
    }
}
